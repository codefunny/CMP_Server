#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <memory.h>
#include <string.h>
#include <strings.h>
#include <signal.h>
#include <sys/msg.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <dlfcn.h>
#include <setjmp.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "log.h"
#include <netdb.h>
#include "pub_base.h"
#include "ap_base.h"
#include "apr_signal.h"
#include "tool_base.h"

extern "C"
{
    int TMS_DownLoad( int nHandle, char cCommType, char * epczDownInfo, char *opczRetInfo );
}

void setupSignals( void )
{
   signal( SIGTERM, SIG_IGN );
   signal( SIGINT,  SIG_IGN );
   signal( SIGPIPE, SIG_IGN );
   signal( SIGHUP,  SIG_IGN );
   signal( SIGCHLD, SIG_IGN );
   signal( SIGTTOU, SIG_IGN );
   signal( SIGTTIN, SIG_IGN );
   signal( SIGTSTP, SIG_IGN );
}

static int _tcp_connect(char *host, int port)
{
   int sock, flags;
   struct sockaddr_in rsock;
   struct hostent * hostinfo;
   struct in_addr * addp;
   struct linger stLinger = { 1, 0 };

   memset ((char *)&rsock,0,sizeof(rsock));

   if ( (hostinfo=gethostbyname(host)) == NULL )
   {
      return -1;
   }

   sock=socket(AF_INET,SOCK_STREAM,0);
   if ( sock == -1 )
   {
      return -1;
   }

   addp=(struct in_addr *)*(hostinfo->h_addr_list);
   rsock.sin_addr=*addp;
   rsock.sin_family=AF_INET;
   rsock.sin_port=htons(port);

   if( connect(sock,(struct sockaddr *)(&rsock),sizeof(rsock)) == -1 )
   {
      close (sock);
      return -1;
   }

   flags = setsockopt( sock, SOL_SOCKET, SO_LINGER, &stLinger,
                       sizeof( struct linger ) );
   if( flags == -1 )
   {
      close (sock);
      return -1;
   }

   return sock;
}

static int _tcp_close( int sock )
{
   return close( sock );
}

static int _tcp_send( int sock, char *buf, int len )
{
   char sendbuf[1001];
   int pos = 0, sendlen;

   do
   {
      sendlen = len - pos;
      if( sendlen > 1000 )
      {
         sendlen = 1000;
      }

      memcpy( sendbuf, buf+pos, sendlen );
      if( write( sock, sendbuf, sendlen  ) == -1 )
      {
         return -1;
      }
      pos += sendlen;
   } while( pos < len );

   return pos;
}

static int _server(char * hostname, int port)
{
    int fdSock, optval;
    struct sockaddr_in srvaddr;

    bzero(&srvaddr, sizeof(struct sockaddr_in));

    if (hostname != NULL) {
        srvaddr.sin_addr.s_addr = inet_addr(hostname);
    } else {
        srvaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    }
    srvaddr.sin_family = AF_INET;
    srvaddr.sin_port = htons(port);

    fdSock = socket(AF_INET, SOCK_STREAM, 0);
    if (fdSock <= 0) 
    {
        return ( -1);
    }

    optval = 1;
    if (setsockopt(fdSock, SOL_SOCKET, SO_REUSEADDR, &optval,
                   sizeof(int)) < 0) {
        close(fdSock);
        return ( -1);
    }

    if (bind(fdSock, (struct sockaddr *)&srvaddr, sizeof(srvaddr)) < 0) {
        close(fdSock);
        return ( -1);
    }

    if (listen(fdSock, 64) < 0) {
        close(fdSock);
        return ( -1);
    }

    return (fdSock);
}

static int _tcp_read(int cd, char *buf, int len, int ntimeout )
{
    ssize_t ileft, iread;
    char *ptr;
    fd_set readset;
    struct timeval tvp ;
    int  maxfd=0;
    int  ret=0;

    ptr = buf;
    ileft = len;
    while (ileft > 0) 
    {
        tvp.tv_sec = ntimeout ;
        tvp.tv_usec = 0 ;
        maxfd = cd + 1 ;
        FD_ZERO( &readset );
        FD_SET( cd, &readset );

        if( ntimeout == 0 )/*������*/
        {
            ret = select(maxfd, &readset, NULL, NULL, NULL) ;
            if( ret <= 0 )
            {
                LOG4C(( LOG_DEBUG, "000000[%d]", ret));
                continue;
            }
        }
        else
        {
            ret = select(maxfd, &readset, NULL, NULL, &tvp) ;
            if( ret <= 0 )
            {
                LOG4C(( LOG_DEBUG, "Ҫ��ȡ�ĳ���[%d] ����ֵ[%d]  ��ʱ�˳�", ileft, ret));
                break;
            }
        }

        if(FD_ISSET(cd, &readset)) 
        {
            iread = read(cd, ptr, ileft);
            if (iread <= 0) 
            {   /* --> partner close socket */
                return (-__LINE__);
            } 
            else 
            {	    /* --> read OK */
                ileft -= iread;
                ptr += iread;
                continue;
            }
        }
    } /* end while */

    ileft = ileft<0? 0:ileft;

    return (len-ileft);
}

static int Dll_Down ( int nSocketHandle, const char *epczTpdu, const char *epczInfo )
{
    void  *handle;
    int   (*func)(int, char, char *, char *);
    char  aczDllName[40];
    char  aczDll[100];
    char  *pError=NULL;
    int   i=0;
    unsigned char  aczLen[3];
    int   nDownLen=0;
    int   nRet=0;
    char  aczRetInfo[1024];
    char  aczBuf[8000];
    char  aczDate[9];
    char  aczTime[7];
    struct stat st;
    char  aczDllLog[256];
    char  aczDllLogBak[256];
    FILE  *fperr=NULL;
    FILE  *fpout=NULL;
    char  *pcTracePath=NULL;
    char  *pcLogDllOn=NULL;
    char  *pcMaxPacket=NULL;
    char  aczMaxPacket[8];
    bool  bLogDll=FALSE;

    memset( &st, 0, sizeof(struct stat) );
    memset( aczDllName, 0, sizeof(aczDllName) );
    memset( aczDll, 0, sizeof(aczDll) );
    memset( aczLen, 0, sizeof(aczLen) );
    memset( aczRetInfo, 0, sizeof(aczRetInfo) );
    memset( aczBuf, 0, sizeof(aczBuf) );
    memset( aczDate, 0, sizeof(aczDate) );
    memset( aczTime, 0, sizeof(aczTime) );
    memset( aczDllLog, 0, sizeof(aczDllLog) );
    memset( aczDllLogBak, 0, sizeof(aczDllLogBak) );
    memset( aczMaxPacket, 0, sizeof(aczMaxPacket) );

    /*TPDU+DLLDLL+�������30B+����2HEX+����*/

    /*TPDU*/
    memcpy( aczBuf, epczTpdu, 5 );

    /*ȡ��̬������*/
    for( i=0; i<30; i++ )
    {
        if( epczInfo[i] != ' ' )
        {
            aczDllName[i] = epczInfo[i];
        }
        else
        {
            break;
        }
    }

    sprintf( aczDll, "%s/lib/%s", getenv("MYROOT"), aczDllName );
    LOG4C(( LOG_DEBUG, "���õ����ӿ�[%s]", aczDll ));

    handle = dlopen( aczDll, RTLD_LAZY );
    if( !handle )
    {
        LOG4C(( LOG_DEBUG, "�����ӿ�[%s]ʧ��", aczDll ));
        return -1;
    }
    func =(int (*) (int, char, char *, char *)) dlsym( handle, "TMS_DownLoad" );
    if ((pError = dlerror()) != NULL)
    {
        LOG4C(( LOG_DEBUG, "�򿪺����ӿ�ʧ��[%s]", pError ));
        dlclose(handle);
        return -1;
    }

    /*ȡ2���ֽڵ�������Ϣ����*/
    memcpy( aczLen, epczInfo+30, 2 );
    nDownLen = aczLen[0] * 256 + aczLen[1];

    LOG4C(( LOG_DEBUG, "�����ļ���Ϣ����[%d] [%02X %02X]", nDownLen, aczLen[0]&0xff, aczLen[1]&0xff ));
    if( nDownLen <= 0 )
    {
        LOG4C(( LOG_FATAL, "�����ļ�����Ϣ����[%d]", nDownLen ));
        dlclose(handle);
        return -1;
    }

    pcMaxPacket = getenv("MAX_PACKET");
    if( pcMaxPacket == NULL )
    {
        strcpy( aczMaxPacket, "1000" );
    }
    else
    {
       strcpy( aczMaxPacket, pcMaxPacket ); 
       if( atoi( aczMaxPacket ) > 8000 )
       {
           strcpy( aczMaxPacket, "8000" );
       }
    }

    /* ��̬������30λ��������Ϣ����2λ */
    memcpy( aczBuf+5, aczMaxPacket, 4 );
    memcpy( aczBuf+9, epczInfo+32, nDownLen );

    TOOL_Dump( LOG_DEBUG, "serial_file.dump", (unsigned char*)aczBuf, 9+nDownLen );

    LOG4C(( LOG_DEBUG, "��������Ѿ��ҵ�,׼����ʼ���ó������ӿ�" ));

    TOOL_GetSystemYYYYMMDD( aczDate );
    TOOL_GetSystemhhmmss( aczTime );

    pcLogDllOn = getenv( "LOG_DLL" );
    if ( pcLogDllOn != NULL )
    {
        if ( pcLogDllOn[0] != '0' )
        {
            bLogDll=TRUE;
        }
    }

    if( bLogDll )
    {
        pcTracePath = (char*)getenv( "TRACE_PATH" );
        if ( pcTracePath != NULL )
        {
            if( *(pcTracePath + strlen( pcTracePath ) - 1 ) == '/' )
            {
                sprintf( aczDllLog, "%slog_%s", pcTracePath, aczDllName );
            }
            else
            {
                sprintf( aczDllLog, "%s/log_%s", pcTracePath, aczDllName );
            }
        }
        else
        {
            pcTracePath = (char*)getenv( "MYROOT" );
            sprintf( aczDllLog, "%s/log/log_%s", pcTracePath, aczDllName );
        }
        sprintf( aczDllLog, "%s.%s", aczDllLog, aczDate );

        stat( aczDllLog, &st );
        if( st.st_size > 1024*1024*30 ) /*30M*/
        {
            sprintf( aczDllLogBak, "%s.%s", aczDllLog, aczTime );
            if( rename( aczDllLog, aczDllLogBak ) < 0 ) 
            {
                LOG4C(( LOG_FATAL, "������־���ݴ���" ));
                dlclose(handle);
                return -1;
            }
        }

        /* ����̬��ĵ�������ض��򵽶�̬����־�ļ� */
        fperr = freopen(aczDllLog, "a+", stderr);
        if( fperr == NULL )
        {
            LOG4C(( LOG_FATAL, "����־����" ));
            dlclose(handle);
            return -1;
        }
        fpout = freopen(aczDllLog, "a+", stdout);
        if( fpout == NULL )
        {
            LOG4C(( LOG_FATAL, "����־����" ));
            fclose( stderr );
            dlclose(handle);
            return -1;
        }
    }

    LOG4C(( LOG_DEBUG, "+++++++++++++++++++++++++++++++++" ));
    LOG4C(( LOG_DEBUG, "[%10d][%s %s]��ʼ����[%s]", getpid(), aczDate, aczTime, aczDll ));
    nRet = func( nSocketHandle, 0x02, aczBuf, aczRetInfo );
    TOOL_GetSystemYYYYMMDD( aczDate );
    TOOL_GetSystemhhmmss( aczTime );
    LOG4C(( LOG_DEBUG, "[%10d][%s %s]��������[%s]", getpid(), aczDate, aczTime, aczDll ));
    LOG4C(( LOG_DEBUG, "---------------------------------" ));
    
    if( bLogDll )
    {
        fclose( stderr );
        fclose( stdout );
    }
    dlclose(handle);

    if( nRet != 0 )
    {
        LOG4C(( LOG_FATAL, "���ӿ����س���[%d][%s]", nRet, aczRetInfo ));
        return -1;
    }
    LOG4C(( LOG_DEBUG, "���ӿ�ִ�гɹ�[%s]", aczRetInfo ));

    return 0;
}

int ReqProc ( int enSock, char *epczBuf, int enLen )
{
    int iRet=0;

    iRet = _tcp_send( enSock, epczBuf, enLen );
    if( iRet == -1 )
    {
        LOG4C(( LOG_FATAL, "�������ݵ������ʧ��" ));
        return -1;
    }

    return 0;
}

int RspProc (int enSerSock, int sock )
{
    int iRet = 0;
    int iLen = 0;
    int iRecvLen=0;
    int iHaveLen=0;
    int i=0;
    char aczBuf[8000];
    char aczPack[1024];
    int iPackLen=0;
    unsigned char aczLen[10];
    unsigned char uCh=0;

    memset( aczBuf, 0, sizeof(aczBuf) );
    memset( aczLen, 0, sizeof(aczLen) );
    iRet = _tcp_read (enSerSock, (char * )aczLen, 2, 70);
    if (iRet <=0 ) 
    {
        LOG4C((LOG_FATAL, "TCPIP���շ���Ӧ���ĳ���ʧ��.[%d]\n", iRet));
        return -1;
    }
    memcpy( aczBuf, aczLen, 2 );
    iLen = aczLen[0]*256+aczLen[1];
    LOG4C(( LOG_DEBUG, "���շ���Ӧ�𳤶� [%d] ���� [%02x %02x]\n", iLen, aczLen[0]&0xff, aczLen[1]&0xff ));
    if( iLen > sizeof(aczBuf)-3 )
    {
        LOG4C(( LOG_FATAL, "��Ч����" ));
        return -1;
    }

    iRet = _tcp_read (enSerSock, aczBuf+2, iLen, 5);
    if (iRet <=0 ) 
    {
        LOG4C((LOG_FATAL, "TCPIP���շ���Ӧ���İ���ʧ��.[%d]\n", iRet));
        return -1;
    }

    if( memcmp( aczBuf+2+5, "DLL001", 6 ) == 0 )
    {
        memset( aczPack, 0, sizeof(aczPack) );
        memcpy( aczPack+2, aczBuf+2, 5 );/*TPDU*/
        memcpy( aczPack+7, aczBuf+2+5+6, 82 );/*����20+�ͺ�20+���к�38+�汾2+��Ӧ��2*/
        uCh = 0;
        for( i=0; i<82; i++ )
            uCh ^= aczPack[7+i];
        aczPack[89] = uCh;

        iPackLen = 88;/* TPDU5 +����20+�ͺ�20+���к�38+�汾2+��Ӧ��2 +LRC 1 =88 */
        aczPack[0] = iPackLen/256;
        aczPack[1] = iPackLen%256;
        iPackLen = 90;

        iRet = _tcp_send( sock, aczPack, iPackLen );
        if( iRet == -1 )
        {
            LOG4C(( LOG_FATAL, "�������ݵ�POSʧ��" ));
            return -1;
        }

        TOOL_Dump( LOG_DEBUG, "serial_send.dump", (unsigned char*)aczPack, iPackLen );

        LOG4C(( LOG_DEBUG, "+++++++++++++++++++++++++++++++++++++++++++++++++" ));
        LOG4C(( LOG_DEBUG, "++++��ʼת������DLL��������" ));
        /*���ܵ��ı��ĸ�ʽΪ LEN2+TPDU+DLLDLL+����20+�ͺ�20+���к�38+�汾2+��Ӧ��2+���ӿ���30B+������Ϣ*/
        iRet =  Dll_Down( sock, aczBuf+2, aczBuf+2+5+6+20+20+38+2+2 );
        LOG4C(( LOG_DEBUG, "++++��������DLL���ò�����[%d]", iRet ));
        LOG4C(( LOG_DEBUG, "+++++++++++++++++++++++++++++++++++++++++++++++++" ));
        return iRet;
    }

    iRet = _tcp_send( sock, aczBuf, iLen+2 );
    if( iRet == -1 )
    {
        LOG4C(( LOG_FATAL, "�������ݵ�POSʧ��" ));
        return -1;
    }

    TOOL_Dump( LOG_DEBUG, "serial_send.dump", (unsigned char*)aczBuf, iLen+2 );

    return 0;
}

static jmp_buf env_alarm;
void AlarmFork( int enPara )
{
    siglongjmp( env_alarm, 1 );
}

int Process( int sockId, char *epczSerIp, int enSerPort )
{
    int iRet = 0;
    int iLen = 0;
    int iRecvLen=0;
    int iHaveLen=0;
    int i=0;
    char aczBuf[3000];
    unsigned char aczLen[10];
    char  aczKill[30];
    pid_t  pid;
    pid_t  pidchild;
    int  iSerSock;
   
    while( 1 )
    {
        LOG4C_OPEN();
        memset( aczBuf, 0, sizeof(aczBuf) );
        memset( aczLen, 0, sizeof(aczLen) );
        iRet = _tcp_read (sockId, (char *)aczLen, 2, 50 );
        if (iRet <=0 ) 
        {
            LOG4C((LOG_FATAL, "TCPIP����POS�����ĳ���ʧ��.[%d] �˳�������\n", iRet));
            LOG4C_CLOSE();
            return -1;
        }
        memcpy( aczBuf, aczLen, 2 );
        iLen = aczLen[0]*256+aczLen[1];
        LOG4C(( LOG_DEBUG, "����POS���󳤶� [%d] ���� [%02x %02x]\n", iLen, aczLen[0]&0xff, aczLen[1]&0xff ));
        if( iLen > sizeof(aczBuf)-3 )
        {
            LOG4C(( LOG_FATAL, "��Ч����" ));
            LOG4C_CLOSE();
            return -1;
        }

        iRet = _tcp_read (sockId, aczBuf+2, iLen, 5);
        if (iRet <=0 ) 
        {
            LOG4C((LOG_FATAL, "TCPIP����POS�����İ���ʧ��.[%d]\n", iRet));
            LOG4C_CLOSE();
            return -1;
        }
        iLen += 2;

        TOOL_Dump( LOG_DEBUG, "serial_recv.dump", (unsigned char*)aczBuf, iLen );
        pid = fork();
        if( pid < 0 )
        {
            LOG4C_CLOSE();
            continue;
        }
        else if (pid == 0)
        {
            iSerSock = _tcp_connect( epczSerIp, enSerPort );
            if( iSerSock == -1 )
            {
                LOG4C(( LOG_FATAL, "��ǰ��[%s:%d]����ʧ��", epczSerIp, enSerPort  ));
                exit(0);
            }

            pidchild = fork();
            if ( pidchild  < 0) 
            {
                LOG4C ((LOG_FATAL, "Fork error." ));
                _tcp_close( iSerSock );
                exit (0);
            } 
            else if (pidchild == 0) 
            {
                RspProc( iSerSock, sockId );
                _tcp_close( iSerSock );
                exit(0);
            } 
            else 
            {
                signal( SIGALRM, AlarmFork );
                alarm( 60*20 ); //20����
                if ( sigsetjmp(env_alarm, 1) != 0 )
                {
                    LOG4C(( LOG_FATAL, "����[%d]��ʱδ�˳�,ִ��ǿ���˳�", pidchild ));
                    alarm( 0 );
                    signal( SIGALRM, SIG_IGN );
                    memset( aczKill, 0, sizeof(aczKill) );
                    sprintf(aczKill, "kill -9 %d", pidchild );
                    system( aczKill );
                    exit(0);
                }

                ReqProc( iSerSock, aczBuf, iLen );
                waitpid( pidchild, NULL, 0 );

                alarm( 0 );
                signal( SIGALRM, SIG_IGN );

                _tcp_close( iSerSock );
                exit(0);
            }
        }
        else
        {
            waitpid( pid, NULL, 0 );
        }
        LOG4C_CLOSE();
    }
    return 0;
}

int main( int argc, char *argv[] )
{
   int iPort;
   int iRet;
   int lscd, sockId;
   char aczServiceIp[30];
   int iServicePort;
   pid_t  pid;
   char  aczEnvConfig[256];
   char  aczLogConfig[256];

   if( getenv("MYROOT") == NULL)
   {
       fprintf( stderr, "Env MYROOT unset\n" );
       return -1;
   }
   memset( aczLogConfig, 0, sizeof(aczLogConfig) );
   memset( aczEnvConfig, 0, sizeof(aczEnvConfig) );
   sprintf( aczEnvConfig, "%s/etc/%s.env", getenv("MYROOT"), argv[0] );
   loadEnviorment( aczEnvConfig );
   sprintf( aczLogConfig, "%s/etc/%s.ini", getenv("MYROOT"), argv[0] );

   if( getenv( "SERVICE_PORT" ) == NULL )
   {
       fprintf( stderr, "Env SERVICE_PORT unset\n" );
       return -1;
   }
   else
   {
       iPort = atoi (getenv( "SERVICE_PORT" ));
   }

   if( getenv( "TMS_IP" ) == NULL )
   {
       fprintf( stderr, "Env TMS_IP unset\n" );
       return -1;
   }
   else
   {
       strcpy (aczServiceIp, getenv( "TMS_IP" ));
   }

   if( getenv( "TMS_PORT" ) == NULL )
   {
       fprintf( stderr, "Env TMS_PORT unset\n" );
       return -1;
   }
   else
   {
       iServicePort = atoi (getenv( "TMS_PORT" ));
   }

   if ((pid = fork()) < 0) 
   {
        fprintf (stderr, "fork error\n");
        return -1;
   }
   else if (pid > 0) 
   {
        exit (0);
   }

   if (setsid () < 0) 
   {
        return -1;
   }

   if ((pid = fork()) < 0) 
   {
        fprintf (stderr, "fork error\n");
        return -1;
   }
   else if (pid > 0) 
   {
        exit (0);
   }

   LOG4C_INIT( aczLogConfig );

   setupSignals();

   lscd = _server (NULL, iPort);

   while (1) 
   {
      sockId = accept (lscd, NULL, NULL) ;
      if (sockId < 0) 
      {
          continue;
      }

      LOG4C_OPEN();
      if ((pid = fork()) < 0) 
      {
          LOG4C ((LOG_FATAL, "Fork error: \n" ));
          close (sockId);
          LOG4C_CLOSE();
          continue;
      } 
      else if (pid == 0) 
      {
          close (lscd);
          Process( sockId , aczServiceIp, iServicePort );
          close( sockId );
          exit( 0 );
      }
      close (sockId);
      LOG4C_CLOSE();
   }

   return 0;
}

